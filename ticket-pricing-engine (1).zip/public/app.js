const state = {
  show: null,
  quantities: {}, // tierId -> quantity
};

const els = {
  showTitle: document.getElementById('show-title'),
  tiers: document.getElementById('tiers'),
  festivalToggle: document.getElementById('festival-toggle'),
  festivalLabel: document.getElementById('festival-label'),
  memberToggle: document.getElementById('member-toggle'),
  memberLabel: document.getElementById('member-label'),
  feeNote: document.getElementById('fee-note'),
  quoteBtn: document.getElementById('quote-btn'),
  confirmBtn: document.getElementById('confirm-btn'),
  message: document.getElementById('message'),
  receipt: document.getElementById('receipt'),
};

function formatRupees(paise) {
  const rupees = paise / 100;
  const sign = rupees < 0 ? '-' : '';
  const formatted = Math.abs(rupees).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${sign}₹${formatted}`;
}

async function loadShow() {
  const res = await fetch('/api/show');
  const show = await res.json();
  state.show = show;
  show.tiers.forEach((t) => (state.quantities[t.id] = 0));
  render();
}

function totalTickets() {
  return Object.values(state.quantities).reduce((a, b) => a + b, 0);
}

function render() {
  els.showTitle.textContent = state.show.title;

  els.festivalLabel.textContent = state.show.offers.festival.label;
  els.memberLabel.textContent = state.show.offers.member.label;
  els.feeNote.textContent = `Every booking adds a convenience fee of ${formatRupees(
    state.show.fees.convenienceFeePerTicketPaise
  )} per ticket, plus ${state.show.fees.gstPercent}% GST.`;

  els.tiers.innerHTML = '';
  state.show.tiers.forEach((tier) => {
    const qty = state.quantities[tier.id];
    const soldOut = tier.availableSeats === 0;

    const card = document.createElement('div');
    card.className = 'tier-card' + (soldOut ? ' sold-out' : '');

    const seatsClass = tier.availableSeats > 0 && tier.availableSeats <= 5 ? 'low' : '';
    card.innerHTML = `
      <div class="tier-info">
        <h3>${tier.name}</h3>
        <span class="price">${tier.basePriceLabel} / seat</span>
        <span class="seats-left ${seatsClass}">
          ${soldOut ? 'Sold out' : `${tier.availableSeats} seat${tier.availableSeats === 1 ? '' : 's'} left`}
        </span>
      </div>
      <div class="stepper">
        <button data-action="dec" data-tier="${tier.id}" ${qty === 0 ? 'disabled' : ''}>−</button>
        <span class="qty">${qty}</span>
        <button data-action="inc" data-tier="${tier.id}" ${qty >= tier.availableSeats ? 'disabled' : ''}>+</button>
      </div>
    `;
    els.tiers.appendChild(card);
  });

  els.tiers.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const tierId = btn.dataset.tier;
      const tier = state.show.tiers.find((t) => t.id === tierId);
      if (btn.dataset.action === 'inc' && state.quantities[tierId] < tier.availableSeats) {
        state.quantities[tierId]++;
      } else if (btn.dataset.action === 'dec' && state.quantities[tierId] > 0) {
        state.quantities[tierId]--;
      }
      hideMessage();
      els.receipt.classList.add('hidden');
      render();
    });
  });

  const hasTickets = totalTickets() > 0;
  els.quoteBtn.disabled = !hasTickets;
  els.confirmBtn.disabled = !hasTickets;
}

function currentTicketLines() {
  return Object.entries(state.quantities)
    .filter(([, qty]) => qty > 0)
    .map(([tierId, quantity]) => ({ tierId, quantity }));
}

function requestBody() {
  return {
    tickets: currentTicketLines(),
    applyFestival: els.festivalToggle.checked,
    isMember: els.memberToggle.checked,
  };
}

function showMessage(text, type) {
  els.message.textContent = text;
  els.message.className = `message ${type}`;
}

function hideMessage() {
  els.message.className = 'message hidden';
}

function renderBreakup(breakup) {
  const rows = breakup.lines
    .map((line) => {
      const isDiscount = line.amountPaise < 0;
      return `<div class="row${isDiscount ? ' discount' : ''}">
        <span>${line.label}</span><span>${formatRupees(line.amountPaise)}</span>
      </div>`;
    })
    .join('');

  els.receipt.innerHTML = `
    ${rows}
    <div class="divider"></div>
    <div class="row total"><span>Grand Total</span><span>${formatRupees(breakup.grandTotalPaise)}</span></div>
  `;
  els.receipt.classList.remove('hidden');
}

async function getQuote() {
  hideMessage();
  try {
    const res = await fetch('/api/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody()),
    });
    const data = await res.json();
    if (!data.ok) {
      showMessage(data.message, 'error');
      els.receipt.classList.add('hidden');
      return;
    }
    renderBreakup(data.breakup);
  } catch (err) {
    showMessage('Could not reach the server. Is it running?', 'error');
  }
}

async function confirmBooking() {
  hideMessage();
  try {
    const res = await fetch('/api/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody()),
    });
    const data = await res.json();
    if (!data.ok) {
      showMessage(data.message, 'error');
      return;
    }
    renderBreakup(data.breakup);
    showMessage(`Booked! Confirmation ID: ${data.bookingId}`, 'success');

    // sync availability, then reset quantities for the next customer
    data.tiers.forEach((t) => {
      const tier = state.show.tiers.find((s) => s.id === t.id);
      tier.availableSeats = t.availableSeats;
      state.quantities[t.id] = 0;
    });
    render();
  } catch (err) {
    showMessage('Could not reach the server. Is it running?', 'error');
  }
}

els.quoteBtn.addEventListener('click', getQuote);
els.confirmBtn.addEventListener('click', confirmBooking);
els.festivalToggle.addEventListener('change', () => {
  els.receipt.classList.add('hidden');
});
els.memberToggle.addEventListener('change', () => {
  els.receipt.classList.add('hidden');
});

loadShow();
