import express, { Request, Response } from 'express';
import path from 'path';
import { fridayNightShow } from './data/sampleShow';
import { priceBooking, formatRupees, availableSeats } from './pricingEngine';
import { SoldOutError, TierNotFoundError, InvalidRequestError } from './errors';
import { OfferConfig, FeeConfig, TicketRequestLine } from './types';

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// --- Counter configuration. In a real system this would live in a DB / admin panel. ---
const FEE_CONFIG: FeeConfig = { convenienceFeePerTicketPaise: 3000, gstPercent: 18 };
const FESTIVAL_OFFER = { flatDiscountPaise: 10000, label: 'Festival Offer — flat ₹100 off' };
const MEMBER_OFFER = { percent: 10, capPaise: 8000, label: 'Member discount — 10% off, capped at ₹80' };

// --- GET /api/show — tiers, live availability, fee/offer config for the UI to render ---
app.get('/api/show', (_req: Request, res: Response) => {
  res.json({
    id: fridayNightShow.id,
    title: fridayNightShow.title,
    fees: FEE_CONFIG,
    offers: { festival: FESTIVAL_OFFER, member: MEMBER_OFFER },
    tiers: fridayNightShow.tiers.map((t) => ({
      id: t.id,
      name: t.name,
      basePricePaise: t.basePricePaise,
      basePriceLabel: formatRupees(t.basePricePaise),
      availableSeats: availableSeats(t),
      totalSeats: t.totalSeats,
    })),
  });
});

function buildOffers(body: any): OfferConfig {
  const offers: OfferConfig = {};
  if (body?.applyFestival) offers.festivalFlatDiscountPaise = FESTIVAL_OFFER.flatDiscountPaise;
  if (body?.isMember) {
    offers.memberDiscountPercent = MEMBER_OFFER.percent;
    offers.memberDiscountCapPaise = MEMBER_OFFER.capPaise;
  }
  return offers;
}

function parseTickets(body: any): TicketRequestLine[] {
  if (!Array.isArray(body?.tickets)) {
    throw new InvalidRequestError('Request body must include a "tickets" array.');
  }
  return body.tickets
    .filter((t: any) => t && Number(t.quantity) > 0)
    .map((t: any) => ({ tierId: String(t.tierId), quantity: Number(t.quantity) }));
}

function handleError(err: unknown, res: Response) {
  if (
    err instanceof SoldOutError ||
    err instanceof TierNotFoundError ||
    err instanceof InvalidRequestError
  ) {
    res.status(400).json({ ok: false, error: err.name, message: err.message });
  } else {
    console.error(err);
    res.status(500).json({ ok: false, error: 'InternalError', message: 'Something went wrong.' });
  }
}

// --- POST /api/quote — price a booking WITHOUT touching seat inventory ---
app.post('/api/quote', (req: Request, res: Response) => {
  try {
    const lines = parseTickets(req.body);
    const offers = buildOffers(req.body);
    const breakup = priceBooking(fridayNightShow, lines, offers, FEE_CONFIG);
    res.json({ ok: true, breakup });
  } catch (err) {
    handleError(err, res);
  }
});

// --- POST /api/confirm — price AND commit: decrements seat availability ---
app.post('/api/confirm', (req: Request, res: Response) => {
  try {
    const lines = parseTickets(req.body);
    const offers = buildOffers(req.body);
    // priceBooking re-validates availability itself — if it doesn't throw, it's safe to commit.
    const breakup = priceBooking(fridayNightShow, lines, offers, FEE_CONFIG);

    for (const line of lines) {
      const tier = fridayNightShow.tiers.find((t) => t.id === line.tierId)!;
      tier.bookedSeats += line.quantity;
    }

    res.json({
      ok: true,
      bookingId: `BK-${Date.now()}`,
      breakup,
      tiers: fridayNightShow.tiers.map((t) => ({ id: t.id, availableSeats: availableSeats(t) })),
    });
  } catch (err) {
    handleError(err, res);
  }
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(PORT, () => {
  console.log(`Ticket booking counter running at http://localhost:${PORT}`);
});
